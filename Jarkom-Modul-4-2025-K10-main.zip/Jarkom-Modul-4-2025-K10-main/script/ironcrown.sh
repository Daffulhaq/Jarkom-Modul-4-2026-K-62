#!/bin/bash

auto eth0
iface eth0 inet static
    address 192.216.15.162
    netmask 255.255.255.240
    gateway 192.216.15.161
up echo nameserver 192.168.122.1 > /etc/resolv.conf
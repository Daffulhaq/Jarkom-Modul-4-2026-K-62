#!/bin/bash

# Interface utama ke Switch3
auto eth0
iface eth0 inet static
    address 192.216.4.2
    netmask 255.255.252.0
    gateway 192.216.4.1
up echo nameserver 192.168.122.1 > /etc/resolv.conf